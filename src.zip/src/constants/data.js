import images from './images'

const logo = [
 {
  logo: images.logo,
 },
];

export default { logo }