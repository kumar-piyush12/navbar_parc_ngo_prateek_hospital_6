import logo from '../assets/logo.jpeg';

export default {
 logo
};